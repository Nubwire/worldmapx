import Footer from '@/components/Footer';
import Header from '@/components/Header';

export default function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: "The Evolution of Cartography Through Ages",
      excerpt: "Explore how mapmaking techniques and styles have evolved from ancient civilizations to modern digital mapping.",
      date: "March 15, 2025",
      author: "Emma Cartwright",
      category: "History",
      image: "https://placehold.co/800x400?text=Cartography+Article"
    },
    {
      id: 2,
      title: "Lost Maps: Rediscovering Historical Treasures",
      excerpt: "The fascinating stories behind rediscovered maps that were thought to be lost to history.",
      date: "March 10, 2025",
      author: "James Historian",
      category: "Discoveries",
      image: "https://placehold.co/800x400?text=Lost+Maps+Article"
    },
    {
      id: 3,
      title: "Collecting Vintage Maps: A Beginner's Guide",
      excerpt: "Essential tips for those starting their journey into collecting historical maps and prints.",
      date: "March 5, 2025",
      author: "Sophia Collector",
      category: "Collecting",
      image: "https://placehold.co/800x400?text=Collecting+Guide"
    },
    {
      id: 4,
      title: "The Art of Map Preservation",
      excerpt: "Learn professional techniques for preserving and caring for antique maps and documents.",
      date: "February 28, 2025",
      author: "Robert Conservator",
      category: "Conservation",
      image: "https://placehold.co/800x400?text=Map+Preservation"
    }
  ];

  return (
    <div>
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4 text-gray-900">WorldMapX Blog</h1>
            <p className="text-xl text-gray-600">
              Insights, stories, and discoveries from the fascinating world of historical maps and documents
            </p>
          </div>
          
          <div className="mb-12">
            <div className="relative rounded-xl overflow-hidden h-96">
              <img 
                src="https://placehold.co/1200x600?text=Featured+Blog+Post" 
                alt="Featured post" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent">
                <div className="absolute bottom-0 left-0 p-8">
                  <span className="bg-[#3B82F6] text-white text-xs px-3 py-1 rounded-full uppercase font-medium">Featured</span>
                  <h2 className="text-white text-3xl font-bold mt-3 mb-2">Maps as Political Statements: How Cartography Shaped History</h2>
                  <p className="text-gray-200 mb-4">Examining how maps have been used as powerful tools for political messaging throughout history.</p>
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-gray-300 mr-3"></div>
                    <div>
                      <p className="text-white font-medium">Alexander Mapper</p>
                      <p className="text-gray-300 text-sm">March 20, 2025 · 10 min read</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {blogPosts.map(post => (
              <div key={post.id} className="bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg">
                <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
                <div className="p-6">
                  <span className="text-[#3B82F6] text-xs font-medium uppercase tracking-wide">{post.category}</span>
                  <h3 className="text-xl font-bold mt-2 mb-3 text-gray-900">{post.title}</h3>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-500">
                      <span>{post.date}</span> · <span>{post.author}</span>
                    </div>
                    <a 
                      href="#" 
                      className="text-[#3B82F6] font-medium text-sm hover:text-blue-700"
                    >
                      Read more →
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <a 
              href="#" 
              className="px-6 py-3 bg-[#3B82F6] hover:bg-blue-600 text-white font-medium rounded-md shadow-sm transition duration-150 ease-in-out"
            >
              Load More Articles
            </a>
          </div>
          
          <div className="mt-16 p-8 bg-gray-50 rounded-xl">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Subscribe to Our Newsletter</h3>
              <p className="text-gray-600 mb-6">Get the latest articles, collection highlights, and exclusive offers delivered directly to your inbox.</p>
              <div className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
                <input 
                  type="email" 
                  placeholder="Enter your email address" 
                  className="flex-grow px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button 
                  className="px-6 py-3 bg-[#3B82F6] hover:bg-blue-600 text-white font-medium rounded-md shadow-sm transition duration-150 ease-in-out"
                >
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}