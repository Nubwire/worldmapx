import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ShopSection from "@/components/ShopSection";
import CuratedCollections from "@/components/CuratedCollections";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 flex flex-col">
      <Header />
      <Hero />
      <ShopSection />
      <CuratedCollections />
      <Footer />
    </div>
  );
}
