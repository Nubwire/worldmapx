import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Shop items API endpoint
  app.get("/api/shop-items", async (req: Request, res: Response) => {
    try {
      // Check if category is provided as a query parameter
      const category = req.query.category as string | undefined;
      
      if (category) {
        const items = await storage.getShopItemsByCategory(category);
        return res.json(items);
      } else {
        const items = await storage.getShopItems();
        return res.json(items);
      }
    } catch (error) {
      console.error("Error fetching shop items:", error);
      return res.status(500).json({ error: "Failed to fetch shop items" });
    }
  });

  // Shop item details API endpoint
  app.get("/api/shop-items/:id", async (req: Request, res: Response) => {
    try {
      const id = req.params.id;
      const item = await storage.getShopItemById(id);
      
      if (!item) {
        return res.status(404).json({ error: "Shop item not found" });
      }
      
      return res.json(item);
    } catch (error) {
      console.error("Error fetching shop item:", error);
      return res.status(500).json({ error: "Failed to fetch shop item" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
