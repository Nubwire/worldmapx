import { users, type User, type InsertUser, shopItems, type ShopItem } from "@shared/schema";
import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Shop items methods
  getShopItems(): Promise<ShopItem[]>;
  getShopItemsByCategory(category: string): Promise<ShopItem[]>;
  getShopItemById(id: string): Promise<ShopItem | undefined>;
}

// Connect to PostgreSQL
const connectionString = process.env.DATABASE_URL as string;
const client = postgres(connectionString);
const db = drizzle(client);

export class PostgresStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getShopItems(): Promise<ShopItem[]> {
    return await db.select().from(shopItems);
  }

  async getShopItemsByCategory(category: string): Promise<ShopItem[]> {
    return await db.select().from(shopItems).where(eq(shopItems.category, category));
  }

  async getShopItemById(id: string): Promise<ShopItem | undefined> {
    const result = await db.select().from(shopItems).where(eq(shopItems.id, id)).limit(1);
    return result[0];
  }
}

// For backward compatibility, create a class that implements both database and memory storage
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  dbStorage: PostgresStorage;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.currentId = 1;
    this.dbStorage = new PostgresStorage();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Use database storage for shop items
  async getShopItems(): Promise<ShopItem[]> {
    return this.dbStorage.getShopItems();
  }

  async getShopItemsByCategory(category: string): Promise<ShopItem[]> {
    return this.dbStorage.getShopItemsByCategory(category);
  }

  async getShopItemById(id: string): Promise<ShopItem | undefined> {
    return this.dbStorage.getShopItemById(id);
  }
}

export const storage = new MemStorage();
