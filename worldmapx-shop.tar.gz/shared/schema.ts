import { pgTable, text, serial, integer, boolean, uuid, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Shop items schema
export const shopItems = pgTable("shop_items", {
  id: uuid("id").primaryKey(),
  category: text("category").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  price: numeric("price").notNull(),
  image_url: text("image_url"),
});

export const insertShopItemSchema = createInsertSchema(shopItems).pick({
  category: true,
  title: true,
  description: true,
  price: true,
  image_url: true,
});

export type InsertShopItem = z.infer<typeof insertShopItemSchema>;
export type ShopItem = typeof shopItems.$inferSelect;
