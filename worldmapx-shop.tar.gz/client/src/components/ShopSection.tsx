import { useEffect, useState } from "react";
import CategoryCard from "./CategoryCard";
import { ShopItem } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function ShopSection() {
  const [itemsByCategory, setItemsByCategory] = useState<Record<string, ShopItem[]>>({
    Maps: [],
    Prints: [],
    Photos: [],
    Ephemera: [],
    Manuscripts: [],
    Other: [],
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAllCategoryItems = async () => {
      setLoading(true);
      try {
        const categories = ['Maps', 'Prints', 'Photos', 'Ephemera', 'Manuscripts', 'Other'];
        const results: Record<string, ShopItem[]> = {};

        // Fetch data for each category
        for (const category of categories) {
          const data = await apiRequest(`/api/shop-items?category=${category}`, {
            method: "GET"
          });
          
          results[category] = data as ShopItem[] || [];
        }

        setItemsByCategory(results);
      } catch (err: any) {
        console.error('Error fetching shop items:', err);
        setError(err instanceof Error ? err.message : String(err));
      } finally {
        setLoading(false);
      }
    };

    fetchAllCategoryItems();
  }, []);

  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 font-heading">Shop Our Collection</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover remarkable artifacts from our curated collection of historical maps, prints, photographs, and more.
          </p>
        </div>

        {error && (
          <div className="text-center p-4 mb-8 bg-red-50 text-red-600 rounded-md">
            Error loading shop items: {error}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-gray-50 rounded-lg overflow-hidden shadow-md p-6 animate-pulse">
                <div className="h-8 bg-gray-200 rounded mb-6"></div>
                <div className="grid grid-cols-2 gap-4">
                  {[...Array(2)].map((_, i) => (
                    <div key={i} className="space-y-2">
                      <div className="aspect-w-1 aspect-h-1 w-full h-32 bg-gray-200 rounded-md"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {Object.entries(itemsByCategory).map(([category, items]) => (
              <CategoryCard 
                key={category} 
                category={category} 
                items={items} 
              />
            ))}
          </div>
        )}

        <div className="text-center">
          <a 
            href="https://paperchaserevival.kit.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-block bg-[#3B82F6] hover:bg-blue-600 text-white font-medium py-3 px-6 rounded-md transition duration-300 shadow-md"
          >
            Join Us – Your Journey Awaits
          </a>
        </div>
      </div>
    </section>
  );
}
