import { useState } from "react";
import { Link } from "wouter";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <a className="text-2xl font-bold text-[#3B82F6] font-heading">
              WorldMapX
            </a>
          </Link>
          <nav className="hidden md:flex ml-8">
            <Link href="/">
              <a className="mr-6 text-gray-700 hover:text-[#3B82F6]">Home</a>
            </Link>
            <Link href="/explore">
              <a className="mr-6 text-gray-700 hover:text-[#3B82F6]">Explore</a>
            </Link>
            <Link href="/collections">
              <a className="mr-6 text-gray-700 hover:text-[#3B82F6]">Collections</a>
            </Link>
            <Link href="/shop">
              <a className="mr-6 text-gray-700 hover:text-[#3B82F6]">Shop</a>
            </Link>
            <Link href="/blog">
              <a className="mr-6 text-gray-700 hover:text-[#3B82F6]">Blog</a>
            </Link>
            <Link href="/about">
              <a className="text-gray-700 hover:text-[#3B82F6]">About</a>
            </Link>
          </nav>
        </div>
        <div className="flex items-center">
          <button 
            className="p-2 mr-2 text-gray-600 hover:text-[#3B82F6] md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <button className="hidden md:flex items-center text-gray-600 hover:text-[#3B82F6]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <span>Search</span>
          </button>
          <button className="ml-4 hidden md:flex items-center text-gray-600 hover:text-[#3B82F6]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
            <span>Account</span>
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t px-4 py-2">
          <nav className="flex flex-col space-y-3 py-2">
            <Link href="/">
              <a className="text-gray-700 hover:text-[#3B82F6]">Home</a>
            </Link>
            <Link href="/explore">
              <a className="text-gray-700 hover:text-[#3B82F6]">Explore</a>
            </Link>
            <Link href="/collections">
              <a className="text-gray-700 hover:text-[#3B82F6]">Collections</a>
            </Link>
            <Link href="/shop">
              <a className="text-gray-700 hover:text-[#3B82F6]">Shop</a>
            </Link>
            <Link href="/blog">
              <a className="text-gray-700 hover:text-[#3B82F6]">Blog</a>
            </Link>
            <Link href="/about">
              <a className="text-gray-700 hover:text-[#3B82F6]">About</a>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
