import { ShopItem } from "@shared/schema";

interface CategoryCardProps {
  category: string;
  items: ShopItem[];
}

export default function CategoryCard({ category, items }: CategoryCardProps) {
  return (
    <div className="bg-gray-50 rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg" id={`${category.toLowerCase()}-category`}>
      <div className="p-6">
        <h3 className="text-xl font-bold mb-6 font-heading">{category}</h3>
        <div className="grid grid-cols-2 gap-4" id={`${category.toLowerCase()}-items`}>
          {items.length > 0 ? (
            items.slice(0, 4).map((item) => (
              <div key={item.id} className="group">
                <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-md bg-gray-200 mb-2">
                  <img 
                    src={item.image_url || "https://placehold.co/600x400?text=Image+Not+Available"} 
                    alt={item.title} 
                    className="h-full w-full object-cover object-center group-hover:opacity-80 transition"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://placehold.co/600x400?text=Image+Not+Available";
                    }}
                  />
                </div>
                <h4 className="text-sm font-medium text-gray-900 truncate">{item.title}</h4>
                <p className="text-sm font-medium text-[#3B82F6]">${String(item.price)}</p>
                <a 
                  href="https://paperchaserevival.kit.com" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="mt-2 inline-block text-xs bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-1 px-2 rounded transition"
                >
                  View Details
                </a>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-center py-4">
              <p className="text-gray-500">No {category.toLowerCase()} items available at the moment.</p>
            </div>
          )}
        </div>
        <div className="mt-6 text-right">
          <a 
            href="https://paperchaserevival.kit.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm font-medium text-[#3B82F6] hover:text-blue-700 flex items-center justify-end"
          >
            View all {category}
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
}
