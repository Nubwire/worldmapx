import { createClient } from '@supabase/supabase-js';

// Use environment variables or fallback to empty strings
// The actual values will be loaded from .env file or environment vars
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseKey = import.meta.env.VITE_SUPABASE_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);